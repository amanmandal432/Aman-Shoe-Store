AMAN SHOE STORE ANDROID PROJECT

Is package mein Android WebView wrapper + website assets hain.
App ID: com.amanshoestore.app
App name: Aman Shoe Store

APK build karne ke liye:
1. Android Studio (latest stable) computer par install karein.
2. Is ZIP ko extract karein.
3. Android Studio > Open > AmanShoeStore folder select karein.
4. Gradle sync complete hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk par milega.

NOTE:
- Yeh Android source project hai, compiled APK abhi nahi.
- Firebase Firestore Rules/Admin Authentication separately secure/configure karna zaroori hai.
- WebView app mein website network/Firebase access ke liye internet permission included hai.
